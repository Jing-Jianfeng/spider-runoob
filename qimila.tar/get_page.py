from lxml.etree import HTML
import requests
import units
from media_dict import playlist

def get_page():
    url="http://qimila.cool/portal.php?mod=list&catid=1"

    url_list=[]
    ct=units.cur_time()
    print(ct[0])
    headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36 Edge/15.15063'}
    myresponse=requests.get(url,headers = headers)
    page=myresponse.text
    #print(page)
    page=HTML(page)
    result=page.xpath("//*[@id=\"portal_block_13_content\"]/div/ul//li/a/@href | //li/a/@title")

    for key in playlist.keys():
        if ct[1] in playlist[key]:

            for i in range(1,len(result),2):
                if result[i].find(key) != -1 and result[i].find(ct[0]) != -1:
                    url_list.append(result[i])
                    detail_url="http://qimila.cool/" + result[i-1]
                    yun_url,summary=get_yun_url(detail_url)
                    url_list.append(yun_url)
                    url_list.append(summary)


    print(url_list)
    return "\r\n".join(url_list)

def get_yun_url(url):
    myresponse = requests.get(url)
    page = myresponse.text
    page = HTML(page)
    result = page.xpath("//table/@id")
    print(result)
    pid=result[0][3:]
    yun_url=page.xpath("//*[@id=\"postmessage_{}\"]/a[last()-1]/@href".format(pid))
    summary=page.xpath("//*[@id=\"postmessage_{}\"]//text()".format(pid))

    summary="".join(summary)
    summary=summary.replace("\r\n\r\n","").split("\r\n")
    #print(type(summary),summary)
    for j in range(0,len(summary)):
        if summary[j].find("liumeiti") != -1:
            summary=summary[j+1:]
            break
    summary = "\r\n".join(summary)
    """
    summary=page.xpath("//*[@id=\"postmessage_{}\"]//text()".format(pid))
    //*[@id="postmessage_177298"]/a/@href
    //tbody/tr/td[@class=\'t_f\']/a/@href
    //*[@id="pid177357"]/tbody/tr[1]/td[2]/div[2]/div[2]/div[1]/table/tbody
    //*[@id="postmessage_177298"]/text()[5]
    //*[@id="postmessage_177357"]/text()[5]
    """

    #print(yun_url)
    #print(summary)
    return yun_url[0],summary

def test():
    url="http://qimila.ltd/forum.php?mod=viewthread&tid=142988"
    url="http://qimila.ltd/forum.php?mod=viewthread&tid=143028"
    get_yun_url(url)


def main():
    text = get_page()
    #test()
    print(text)
if __name__ == '__main__':
    main()