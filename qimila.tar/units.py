import time

def cur_time():
    time_couple=()
    day=format_date(time.localtime().tm_mday)
    year=format_date(time.localtime().tm_year)
    month=format_date(time.localtime().tm_mon)
    week=time.localtime().tm_wday + 1

    time_couple=year + "-" + month + "-" + day ,week
    return time_couple

def format_date(num):
    if num < 10:
        return "0" + str(num)
    elif num >= 10:
        return str(num)
    else:
        return None


def main():

    print(cur_time())


if __name__ == "__main__":
    main()